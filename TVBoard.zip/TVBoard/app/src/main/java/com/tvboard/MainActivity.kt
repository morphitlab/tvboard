package com.tvboard
import android.app.Activity
import android.graphics.*
import android.os.Bundle
import android.view.*
import android.webkit.WebView
import com.google.zxing.*
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoWSD
import java.io.*
import java.net.*
import java.util.concurrent.CopyOnWriteArrayList

class Hub(port: Int, val page: String, val url: String, val png: ByteArray) : NanoWSD(port) {
    val socks = CopyOnWriteArrayList<WS>()
    val log = ArrayList<String>()
    inner class WS(h: NanoHTTPD.IHTTPSession) : WebSocket(h) {
        override fun onOpen() { synchronized(log) { log.forEach { send(it) }; socks.add(this) } }
        override fun onClose(c: WebSocketFrame.CloseCode?, r: String?, i: Boolean) { socks.remove(this) }
        override fun onMessage(m: WebSocketFrame) {
            val t = m.textPayload
            synchronized(log) {
                if (!t.contains("\"t\":\"hi\"")) { if (t.contains("\"t\":\"x\"")) log.clear(); log.add(t) }
                socks.forEach { if (it !== this) try { it.send(t) } catch (e: Exception) {} }
            }
        }
        override fun onPong(p: WebSocketFrame?) {}
        override fun onException(e: IOException?) {}
    }
    override fun openWebSocket(h: NanoHTTPD.IHTTPSession) = WS(h)
    override fun serveHttp(s: NanoHTTPD.IHTTPSession): NanoHTTPD.Response = when (s.uri) {
        "/qr.png" -> newFixedLengthResponse(NanoHTTPD.Response.Status.OK, "image/png", ByteArrayInputStream(png), png.size.toLong())
        "/info" -> newFixedLengthResponse(url)
        else -> newFixedLengthResponse(NanoHTTPD.Response.Status.OK, "text/html", page)
    }
}

class MainActivity : Activity() {
    lateinit var hub: Hub
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val url = "http://${localIp()}:8080"
        hub = Hub(8080, assets.open("index.html").bufferedReader().readText(), url, qrPng(url))
        hub.start(0, false)
        val wv = WebView(this)
        wv.setBackgroundColor(Color.BLACK)
        wv.settings.javaScriptEnabled = true
        wv.loadUrl("http://127.0.0.1:8080/?tv")
        setContentView(wv); wv.requestFocus()
    }
    override fun onDestroy() { hub.stop(); super.onDestroy() }
    fun localIp() = NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
        .firstOrNull { !it.isLoopbackAddress && it is Inet4Address }?.hostAddress ?: "127.0.0.1"
    fun qrPng(t: String): ByteArray {
        val m = MultiFormatWriter().encode(t, BarcodeFormat.QR_CODE, 600, 600, mapOf(EncodeHintType.MARGIN to 1))
        val bm = Bitmap.createBitmap(600, 600, Bitmap.Config.ARGB_8888)
        for (x in 0 until 600) for (y in 0 until 600) bm.setPixel(x, y, if (m[x, y]) Color.BLACK else Color.WHITE)
        val o = ByteArrayOutputStream(); bm.compress(Bitmap.CompressFormat.PNG, 100, o); return o.toByteArray()
    }
}
