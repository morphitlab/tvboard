plugins{id("com.android.application");id("org.jetbrains.kotlin.android")}
android{namespace="com.tvboard";compileSdk=34
defaultConfig{applicationId="com.tvboard";minSdk=21;targetSdk=34;versionCode=1;versionName="1.0"}
compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
kotlinOptions{jvmTarget="17"}}
dependencies{implementation("org.nanohttpd:nanohttpd:2.3.1");implementation("org.nanohttpd:nanohttpd-websocket:2.3.1");implementation("com.google.zxing:core:3.5.3")}
